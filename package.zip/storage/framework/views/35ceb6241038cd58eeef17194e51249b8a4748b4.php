<!-- Footer -->
<footer class="sticky-footer bg-white mt-5">
    <div class="container my-auto">
        <div class="copyright text-center my-auto">
            <span>Copyright &copy; <?php echo e(App\Setting::where('slug','nama-toko')->get()->first()->description); ?> <?php echo e(date('Y')); ?> | Repost by <a href='https://stokcoding.com/' title='StokCoding.com' target='_blank'>StokCoding.com</a>
            </span>
        </div>
    </div>
</footer>
<!-- End of Footer -->
<?php /**PATH C:\laragon\www\kas\resources\views/backend/component/footer.blade.php ENDPATH**/ ?>