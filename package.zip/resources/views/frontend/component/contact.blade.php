<!-- HUBUNGI KAMI -->
<section class="mosh-call-to-action-area section_padding_100">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="text-center wow fadeIn" data-wow-delay="0.5s">
                    <div class="section-heading">
                        <h2 class="text-dark">Hubungi Kami</h2>
                        <p class="text-red pt-3">Kami selalu siap menerima kaba dari anda</p>
                    </div>
                    <a href="https://wa.me/{{setting('wa_number')}}?text={{setting('wa_text')}}" class="btn mosh-btn shadow align-middle" style="font-size: 18px">
                        <i class="fab fa-whatsapp"></i>
                        <span>Hubungi Kami</span>
                    </a>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- HUBUNGI KAMI END -->
